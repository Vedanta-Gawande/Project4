package gui;

import javafx.application.*;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.*;

public class InterestTableGUI extends Application {
	
	private TextArea displayTextArea;

	@Override
	public void start(Stage primaryStage) {
		int sceneWidth = 575, sceneHeight = 300;
		int verSpaceBetweenNodes = 8, horSpaceBetweenNodes = 8;
		
		int paneBorderTop = 10, paneBorderRight = 10;
		int paneBorderBottom = 0, paneBorderLeft = 10;

		ScrollPane displayArea = new ScrollPane(displayTextArea);
		//Top Half of the Scene
		displayTextArea = new TextArea();
		//displayTextArea.setPrefSize(sceneWidth, 0.60*sceneHeight);
		displayTextArea.setEditable(false);
		displayTextArea.setWrapText(true);
		
		//Bottom Half of the Scene
		GridPane bottomPane = new GridPane();
		bottomPane.setHgap(horSpaceBetweenNodes);
		bottomPane.setVgap(verSpaceBetweenNodes);
		bottomPane.setPadding(new Insets(paneBorderTop, paneBorderRight, 
			    paneBorderBottom, paneBorderLeft));
		
		
		bottomPane.getColumnConstraints().add(new ColumnConstraints(100));
		bottomPane.getColumnConstraints().add(new ColumnConstraints(150));
		
		//Principal Label and Text Box
		Label principalLabel = new Label("Principal: ");
		TextField principal = new TextField();
		bottomPane.add(principalLabel, 0, 0);
		GridPane.setHalignment(principalLabel, HPos.CENTER);
		GridPane.setValignment(principalLabel, VPos.CENTER);
		bottomPane.add(principal, 1, 0);
		GridPane.setHalignment(principal, HPos.CENTER);
		GridPane.setValignment(principal, VPos.CENTER);
		
		// Rate(Percentage) Label and Text Box
		Label rateLabel = new Label("Rate(Percentage): ");
		TextField rate = new TextField();
		bottomPane.add(rateLabel, 2, 0);
		GridPane.setHalignment(rateLabel, HPos.CENTER);
		GridPane.setValignment(rateLabel, VPos.CENTER);
		bottomPane.add(rate, 3, 0);
		GridPane.setHalignment(rate, HPos.CENTER);
		GridPane.setValignment(rate, VPos.CENTER);
		
		// Number of Years Label and Slider
		Label numOfYearsLabel = new Label("Number of Years: ");
		Slider horizontalSlider = new Slider();
		horizontalSlider.setMin(1);
		horizontalSlider.setMax(25);
		horizontalSlider.setValue(25);
		horizontalSlider.setMajorTickUnit(4);
		horizontalSlider.setShowTickMarks(true);
		horizontalSlider.setShowTickLabels(true);
		
		bottomPane.add(numOfYearsLabel, 1, 1);
		GridPane.setHalignment(numOfYearsLabel, HPos.CENTER);
		GridPane.setValignment(numOfYearsLabel, VPos.CENTER);
		bottomPane.add(horizontalSlider, 2, 1);
		GridPane.setHalignment(horizontalSlider, HPos.CENTER);
		GridPane.setValignment(horizontalSlider, VPos.CENTER);
		
		
		Button SimpIntrButton = new Button("SimpleInterest");
		bottomPane.add(SimpIntrButton, 0, 2);
		GridPane.setHalignment(SimpIntrButton, HPos.RIGHT);
		GridPane.setValignment(SimpIntrButton, VPos.CENTER);
		
		Button CompIntrButton = new Button("CompoundInterest");
		bottomPane.add(CompIntrButton, 1, 2);
		GridPane.setHalignment(CompIntrButton, HPos.RIGHT);
		GridPane.setValignment(CompIntrButton, VPos.CENTER);
		
		Button BothIntrButton = new Button("BothInterests");
		bottomPane.add(BothIntrButton, 2, 2);
		GridPane.setHalignment(BothIntrButton, HPos.RIGHT);
		GridPane.setValignment(BothIntrButton, VPos.CENTER);
		
		//Main Pane in this Scene
		BorderPane borderPane = new BorderPane();
		displayArea.setPrefHeight(180);
		borderPane.setTop(displayArea);
		borderPane.setCenter(bottomPane);

		
		Scene scene = new Scene(borderPane, sceneWidth, sceneHeight);
		primaryStage.setTitle("Interest Table Calculator");
		primaryStage.setScene(scene);
		primaryStage.show();
		
	}
	
	public static void main(String[] args) {
		Application.launch(args);
	}

}
