package model;

public class Interest {
	
}
